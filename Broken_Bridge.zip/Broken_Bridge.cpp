#include<iostream>
#include<string>

bool isBridgeSafe(std::string &bridge,int len){

 for (int i = 0; i<len; i++){

     if (bridge[i] == ' '){

         return false;

     }
     if(i == len){

         break;

     }
 }
 return true;

}

int main(){

    std::string bridge = "## #";
    int len = bridge.length();

    

    std::cout<<isBridgeSafe(bridge, len)<< std::endl;

    return 0;
}

