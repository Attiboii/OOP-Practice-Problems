#include<iostream>
#include<string>
#include<cmath>


double cubeDiagonal(double volume){

//cubed root of volume will give me side

double edge  = std::cbrt(volume);

// side 8 square root of 3 = diagonal

double diag = edge * std::sqrt(3);

return diag;


}


int main(){


    double volume = 8;

    std::cout<<cubeDiagonal(volume)<<std::endl;


    return 0;

}